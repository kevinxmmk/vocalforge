plugins {
    id("com.android.application")
}

android {
    namespace = "com.vocalforge.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vocalforge.app"
        // Android 7.0+. Poco X3 Pro (Android 11 / MIUI 12-14) jauh di atas ini.
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// Tahap 1: sengaja TANPA dependensi tambahan (tanpa AndroidX/Kotlin)
// supaya risiko gagal build sekecil mungkin.
