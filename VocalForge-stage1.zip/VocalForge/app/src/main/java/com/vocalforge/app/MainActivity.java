package com.vocalforge.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Tahap 1: layar dasar dark mode untuk memastikan APK bisa
 * di-build, diinstal, dan dibuka tanpa crash di Android.
 * Fitur audio ditambahkan di tahap berikutnya.
 */
public class MainActivity extends Activity {

    private static final int BG = Color.parseColor("#0E0F13");
    private static final int ACCENT = Color.parseColor("#7C5CFF");
    private static final int TEXT = Color.parseColor("#ECEDF2");
    private static final int MUTED = Color.parseColor("#8B8FA3");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(BG);
        int pad = dp(24);
        root.setPadding(pad, pad, pad, pad);

        root.addView(label("VocalForge", 34, TEXT, true, 0));
        root.addView(label("Acapella Harmonic Studio", 16, ACCENT, false, dp(4)));
        root.addView(label("Tahap 1 — APK dasar berjalan", 14, MUTED, false, dp(32)));
        root.addView(label(
                "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") · " + Build.MODEL,
                12, MUTED, false, dp(8)));

        setContentView(root);
    }

    private TextView label(String text, int sp, int color, boolean bold, int topMargin) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        if (bold) {
            tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = topMargin;
        tv.setLayoutParams(lp);
        return tv;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
